CS440-War-Game
==============

UIUC CS440::Fall 2012 War Game Assignment

Dependencies:
 * python2
 * pygame

How to run:
    python2 wargame.py -b <custom board file>

Board files are found in the boards/ directory.

How to play:
 * Drop: when it's your turn, click on an open spot to capture it
 * Blitz: click an existing captured spot of yours, then drag to an adjacent open square to capture surrounding enemy squares
